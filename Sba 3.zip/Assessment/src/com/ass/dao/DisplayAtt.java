package com.ass.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ass.model.StudentStatus;

public class DisplayAtt {
	
	private static final String GET_STUDENT_ATTE = "select * from attendance where sem =? AND dateOfAtt=?";
	
	public static List<StudentStatus> getAttendance(int sem,Date date) throws SQLException{
		List<StudentStatus> students = null;
		StudentStatus std = null;
		
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs", "pass");
            PreparedStatement psmt=con.prepareStatement(GET_STUDENT_ATTE);
            psmt.setInt(1, sem);
            psmt.setDate(2, date);
            
            ResultSet rs = psmt.executeQuery();
            
            students = new ArrayList<StudentStatus>();
            while(rs.next()) {
            	std = new StudentStatus(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getDate(4), rs.getString(5));
            	students.add(std);
            }
            
		return students;
	}

}
