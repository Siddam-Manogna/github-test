package com.ass.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ass.model.Student;
import com.ass.model.StudentStatus;

public class SaveStudentDao {
	private static final String UPDATE_STUDENT_ATT = "update attendance set attendance='PRESENT' where sid=?";

	public static int saveStudent(StudentStatus std) throws SQLException {
		List<Student> listStudent = new ArrayList<>();
		int noOfRowsAff = 0;
		try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs", "pass")) {
			String sql = "insert into attendance(sid,sname,sem,dateofatt,attendance) values(?,?,?,?,?)";
			PreparedStatement psmt = con.prepareStatement(sql);
			psmt.setInt(1, std.getSid());
			psmt.setString(2, std.getSname());
			psmt.setInt(3, std.getSem());
			psmt.setDate(4, std.getDateOfAtt());
			psmt.setNString(5, std.getAttendance());

			noOfRowsAff = psmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
			throw ex;
		}
		return noOfRowsAff;
	}

	public static int updateStudent(int id) throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs", "pass");
		PreparedStatement psmt = con.prepareStatement(UPDATE_STUDENT_ATT);
		psmt.setInt(1, id);
		int rowsAffect = psmt.executeUpdate();

		return rowsAffect;
	}

}
