package com.ass.model;

public class Student {

	protected int sid;
	protected String sname;
	protected int sem;
	protected String branch;
	
	

	public Student() {
		
	}

	public Student(int sid, String sname, int sem, String branch) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sem = sem;
		this.branch = branch;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getSem() {
		return sem;
	}

	public void setSem(int sem) {
		this.sem = sem;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", sem=" + sem + ", branch=" + branch + "]";
	}
	
	

}
