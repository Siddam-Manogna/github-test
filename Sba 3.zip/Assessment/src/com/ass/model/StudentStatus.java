package com.ass.model;

import java.sql.Date;

public class StudentStatus {

	protected int sid;
	protected String sname;
	protected int sem;
	protected Date dateOfAtt;
	protected String attendance;

	public StudentStatus() {
	}

	public StudentStatus(int sid, String sname, int sem, Date date, String attendance) {
		this.sid = sid;
		this.sname = sname;
		this.sem = sem;
		this.dateOfAtt = date;
		this.attendance = attendance;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getSem() {
		return sem;
	}

	public void setSem(int sem) {
		this.sem = sem;
	}

	public Date getDateOfAtt() {
		return dateOfAtt;
	}

	public void setDateOfAtt(Date dateOfAtt) {
		this.dateOfAtt = dateOfAtt;
	}

	public String getAttendance() {
		return attendance;
	}

	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}

	@Override
	public String toString() {
		return "StudentStatus [sid=" + sid + ", sname=" + sname + ", sem=" + sem + ", dateOfAtt=" + dateOfAtt
				+ ", attendance=" + attendance + "]";
	}

}
