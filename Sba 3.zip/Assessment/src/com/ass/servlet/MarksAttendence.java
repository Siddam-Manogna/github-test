package com.ass.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ass.db.UtilityConnection;
import com.ass.model.Student;

@WebServlet("/marks")
public class MarksAttendence extends HttpServlet {

	private final String GET_STUDENT_SEM ="select * from student where sem=?";
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		List<Student> students = null;
		
		
		int semId = Integer.parseInt(request.getParameter("sem"));
		
		PrintWriter out = response.getWriter();
		out.print("<h1> SemId : "+semId+" </h1>");
		try {
			con = UtilityConnection.getConnection();
			psmt = con.prepareStatement(GET_STUDENT_SEM);
			psmt.setInt(1, semId);
			rs = psmt.executeQuery();
			
			students = new ArrayList<Student>();
			while(rs.next()) {
				Student std = new Student(rs.getInt("SID"), rs.getNString("SNAME"), rs.getInt("SEM"), rs.getString("BRANCH"));
				students.add(std);
			}
			
			request.setAttribute("students", students);
			
			HttpSession session=request.getSession();
			session.setAttribute("students", students);
			System.out.println(students);
			 RequestDispatcher dispatcher = request.getRequestDispatcher("student.jsp");
	         dispatcher.forward(request, response);
	         
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}
