package com.ass.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ass.dao.SaveStudentDao;
import com.ass.model.Student;
import com.ass.model.StudentStatus;

@WebServlet("/saveStudentServlet")
public class SaveStudentServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		/*
		 * Enumeration<String> parmeters = request.getParameterNames();
		 * while(parmeters.hasMoreElements()) { String pname = parmeters.nextElement();
		 * String value = request.getParameter(pname);
		 * out.print("<h1> Param Values : "+value+"</h1>"); }
		 */
		List<Student> students = null;

		StudentStatus sta = null;
		long d = System.currentTimeMillis();
		Date date = new Date(d);

		String[] names = request.getParameterValues("state");
		HttpSession session = request.getSession();

		if (session != null) {
			students = (List<Student>) session.getAttribute("students");
		}

		for (Student s : students) {
			sta = new StudentStatus(s.getSid(), s.getSname(), s.getSem(), date, "ABSENT");
			try {
				SaveStudentDao.saveStudent(sta);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		for (String n : names) {
			int sids = Integer.parseInt(n);
			try {
				int result = SaveStudentDao.updateStudent(sids);
				System.out.println("No of roes aff : " + result);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/*
		 * for (String n : names) { int sids = Integer.parseInt(n); for (Student s :
		 * students) { if (s.getSid() == sids) { sta = new StudentStatus(s.getSid(),
		 * s.getSname(), s.getSem(), date, "PRESENT"); } else { sta = new
		 * StudentStatus(s.getSid(), s.getSname(), s.getSem(), date, "ABSENT"); }
		 * 
		 * try { SaveStudentDao.saveStudent(sta); } catch (SQLException e) {
		 * e.printStackTrace(); } }
		 */

		RequestDispatcher rd = request.getRequestDispatcher("Att.jsp");
		rd.forward(request, response);
	}

}
