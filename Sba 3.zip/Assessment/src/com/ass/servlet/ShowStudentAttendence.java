package com.ass.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ass.dao.DisplayAtt;
import com.ass.model.StudentStatus;

@WebServlet("/showAttendance")
public class ShowStudentAttendence extends HttpServlet {
	private final String GET_STUDENT_SEM = "select * from attendance where sem=?";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int sem = 0;
		List<StudentStatus> studentsAtt = null;
		PrintWriter out = null;

		out = response.getWriter();

		sem = Integer.parseInt(request.getParameter("sem"));
		String sdate = request.getParameter("date").replace('/', '-');
		System.out.println("sdate :  "+sdate);
		long d = System.currentTimeMillis();
		Date date = new Date(d);
		
		try {
			studentsAtt = DisplayAtt.getAttendance(sem, date);
			System.out.print(studentsAtt);
			request.setAttribute("studentsAtt", studentsAtt);
			
			RequestDispatcher rd = request.getRequestDispatcher("DispAtt.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
