package com.myproj.storemongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoremongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoremongoApplication.class, args);
	}

}
