package com.myproj.storemongo.dao;

import java.awt.List;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import com.myproj.storemongo.model.StoreBook;


@Component
public class StoreBookDao {
	@Autowired
	MongoTemplate mongoTemplate;


	public StoreBook saveBook(StoreBook storebook)
	{
	try
	{
	mongoTemplate.save(storebook);
	return storebook;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	public ArrayList<StoreBook> getAllbooks()
	{

	return (ArrayList<StoreBook>) mongoTemplate.findAll(StoreBook.class);

	}
	
	public StoreBook createBook(StoreBook storebook)
	{
	try
	{
	mongoTemplate.save(storebook);
	return storebook;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	public StoreBook UpdateBook(StoreBook storebook)
	{
	try
	{
	mongoTemplate.save(storebook);
	return storebook;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}

	

	}
	
	


