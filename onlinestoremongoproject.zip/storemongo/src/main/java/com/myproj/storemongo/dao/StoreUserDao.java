package com.myproj.storemongo.dao;

import java.awt.List;
import java.util.ArrayList;

import javax.management.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.data.mongodb.core.query.Criteria;



import com.myproj.storemongo.model.StoreUser;

@Component
public class StoreUserDao {
	@Autowired
	MongoTemplate mongoTemplate;


	public StoreUser saveUser(StoreUser storeuser)
	{
	try
	{
	mongoTemplate.save(storeuser);
	return storeuser;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	
	
	public ArrayList<StoreUser> getAll()
	{

	return (ArrayList<StoreUser>) mongoTemplate.findAll(StoreUser.class);

	}
	
	public StoreUser createUser(StoreUser storeuser)
	{
	try
	{
	mongoTemplate.save(storeuser);
	return storeuser;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	
	public StoreUser delUser(StoreUser storeuser)
	{
	try
	{
	mongoTemplate.remove(storeuser);
	return storeuser;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}

	}

	
	
	


