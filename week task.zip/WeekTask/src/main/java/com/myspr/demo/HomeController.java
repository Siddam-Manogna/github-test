package com.myspr.demo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.myspr.demo.Model.Class;
import com.myspr.demo.dao.ClassDao;


@Controller
public class HomeController {

@Autowired
ClassDao dao;



@RequestMapping(value="/")
public String home(Model model)
{
return "home";
}

@RequestMapping(value="/display")
public String display(Model model,@ModelAttribute Class cls)
{
String status=dao.saveClass(cls);
model.addAttribute("status",status);
return "display";
}
@RequestMapping(value="/search")
public String search(Model model,@RequestParam int id)
{
ArrayList<Class> status=dao.getbyId(id);
//System.out.println(status);
model.addAttribute("status",status);
return "search";
}


@RequestMapping(value="/search1")
public String search1(Model model,@RequestParam String name)
{
ArrayList<Class> status=dao.getbyname(name);
//System.out.println(status);
model.addAttribute("status",status);
return "search1";
}
@RequestMapping(value="/delete")
public String delete(Model model,@RequestParam ("name") String name)
{
String status=dao.deletebyname(name);
model.addAttribute("status",status);

return "delete";
}

@RequestMapping(value="/delete1")
public String delete1(Model model,@RequestParam ("id") int id)
{
String status=dao.deletebyid(id);
model.addAttribute("status",status);

return "delete1";
}

}