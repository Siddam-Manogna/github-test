package com.myspr.demo.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Class {
	@Id
	int sId;
	String StuName;
	String sGender;
	public int getcId() {
		return sId;
	}
	public void setcId(int sId) {
		this.sId = sId;
	}
	public String getStuName() {
		return StuName;
	}
	public void setStuName(String stuName) {
		StuName = stuName;
	}
	public String getsGender() {
		return sGender;
	}
	public void setsGender(String sGender) {
		this.sGender = sGender;
	}
	public Class(int sId, String stuName, String sGender) {
		super();
		this.sId = sId;
		StuName = stuName;
		this.sGender = sGender;
	}
	@Override
	public String toString() {
		return "Class [sId=" + sId + ", StuName=" + StuName + ", sGender=" + sGender + "]";
	}
	public Class() {
		
	}
}
