package com.myspr.demo.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.myspr.demo.Model.Class;

import antlr.collections.List;



@Transactional
public class ClassDao {


@Autowired
SessionFactory factory;


public ClassDao() {
// TODO Auto-generated constructor stub
}


public  ClassDao(SessionFactory factory) {
super();
this.factory = factory;
}


public String saveClass(Class cls){
try{
Session session=factory.getCurrentSession();
session.save(cls);
return "class Created";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "cannot create class";
}
public  ArrayList<Class> getbyId(int id) {

try{
Session session=factory.getCurrentSession();
Criteria crit = session.createCriteria(Class.class);
Query query=session.createQuery("from Class c where c.id=:id");
query.setParameter("id", id);
ArrayList<Class> byid=(ArrayList<Class>) query.list();
return byid;

}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}
return null;
}

public ArrayList<Class> getbyname(String name) {

try{
Session session=factory.getCurrentSession();
Criteria crit = session.createCriteria(Class.class);
Query query=session.createQuery("from Class b where b.name=:name");
query.setParameter("name", name);
ArrayList<Class> byname=(ArrayList<Class>) query.list();
return byname;

}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}
return null;
}

public String deletebyname(String name){
try
{

String hql="delete from Class f where f.name = :name";
Session session= factory.openSession();
Query query=(Query) session.createSQLQuery(hql);
query.setParameter("name",name);
    int res=query.executeUpdate();
if(res>0)
return "Record is Successfully deleted!!!!";
}


catch (Exception e) {
e.printStackTrace();

}

return "Sorry could not delete !!!!!!";
}
public String deletebyid(int id){
try
{

String hql="delete from Class g where g.id = :id";
Session session= factory.openSession();
Query query=(Query) session.createSQLQuery(hql);
query.setParameter("id",id);
    int res=query.executeUpdate();
if(res>0)
return "Record is Successfully deleted!!!!";
}


catch (Exception e) {
e.printStackTrace();

}

return "Sorry could not delete !!!!!!";
}


}