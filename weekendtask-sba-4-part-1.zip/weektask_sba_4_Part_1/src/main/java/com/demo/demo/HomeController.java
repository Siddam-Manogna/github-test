package com.demo.demo;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.demo.dao.ClassDao;
import com.demo.demo.model.Class;
@Controller
public class HomeController {
	
	@Autowired
	ClassDao dao;
	



	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
	return "home";
	}

	@RequestMapping(value="/savestud")
	public String savestudent(Model model,@ModelAttribute Class cls)
	{
		String status=dao.saveClass(cls);
		model.addAttribute("status",status);
	return "displayall";
	}



	/*
	* @RequestMapping(value="/display") public String display(Model
	* model,@ModelAttribute School school) {
	*
	* return "display"; }
	*/

	@RequestMapping(value="/search")
	public String search(Model model,@RequestParam int id)
	{
	List<Class> status=dao.getbyId(id);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}


	@RequestMapping(value="/search1")
	public String search1(Model model,@RequestParam String name)
	{
	List<Class> status=dao.getbyname(name);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}


	@RequestMapping(value="/search2")
	public String search4(Model model,@RequestParam int age)
	{
	List<Class> status=dao.getbyage(age);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}

	

	@RequestMapping(value="/updatepage")
	 public String update() {
	return  "updatepage";
	 }
	 
	int id=0;
	 
	 @RequestMapping(value="/searchForUpdate")
	 public String searchForUpdate(Model model,@RequestParam("id")int id) {
	int cid=id;
	this.id=cid;
	Class cls=dao.updatingbyId(cid);
	model.addAttribute("cls",cls);
	 return "updatepage";
	 }
	 


	@RequestMapping(value="/updatedata")
	public String updateData(Model model,@ModelAttribute Class cls) {
	 cls.setId(id);
	// System.out.println(id);
	String up=dao.updateClass(cls);
	model.addAttribute("up",up);
	//System.out.println(up);

	return "updatepage";
	}


	@RequestMapping(value="/delete")
	public String delete(Model model,@RequestParam ("name") String name)
	{
	String status=dao.deletebyname(name);
	model.addAttribute("status",status);

	return "displayall";
	}


	@RequestMapping(value="/delete1")
	public String delete1(Model model,@RequestParam ("id") int id)
	{
	String status=dao.deletebyid(id);
	model.addAttribute("status",status);

	return "displayall";
	}


	}