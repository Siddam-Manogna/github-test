package com.demo.demo.dao;

import javax.transaction.Transactional;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.demo.demo.model.Class;


@Transactional
public class ClassDao {

@Autowired
SessionFactory factory;


public ClassDao() {
// TODO Auto-generated constructor stub
}


public ClassDao(SessionFactory factory) {
super();
this.factory = factory;
}


public String saveClass(Class cls){
try{
Session session=factory.getCurrentSession();
session.save(cls);
return "Successfully inserted details!!!!!!!!!";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "Sorry , cannot enter details!!!!";
}



public List<Class> getbyId(int id) {

try{
Session session=factory.getCurrentSession();
Criteria crit = session.createCriteria(Class.class);
Query query=session.createQuery("from Class a where a.id=:id");
query.setParameter("id", id);
ArrayList<Class> byid=(ArrayList<Class>) query.list();
return byid;

}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}
return null;
}



public List<Class> getbyname(String name) {

try{
Session session=factory.getCurrentSession();
Criteria crit = session.createCriteria(Class.class);
Query query=session.createQuery("from Class b where b.name=:name");
query.setParameter("name", name);
ArrayList<Class> byname=(ArrayList<Class>) query.list();
return byname;

}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}
return null;
}



public List<Class> getbyage(int age) {

try{
Session session=factory.getCurrentSession();
Criteria crit = session.createCriteria(Class.class);
Query query=session.createQuery("from Class e where e.age=:age");
query.setParameter("age",age);
ArrayList<Class> byage=(ArrayList<Class>) query.list();
return byage;

}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}
return null;
}


public Class updatingbyId(int id){
try{
Session session=factory.getCurrentSession();
Class cls=(Class)session.get(Class.class,id);
return cls;
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return null;
}



public String updateClass(Class cls){
try{
Session session=factory.getCurrentSession();
    System.out.println("class "+cls);
session.update("class",cls);
return "Successfully Student Details updated";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "Sorry could not update Student Details";
}



public String updateClassById(Class cls){
try{
Session session=factory.getCurrentSession();

System.out.println("cls "+cls);
session.update("cls",cls);
return "Class Updated";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "Cannot Update Class";
}

/*public String updateClassByname(Class cls){
try{
Session session=factory.getCurrentSession();

System.out.println("cls "+cls);
session.update("cls",cls);
return "Successfully Student Details updated";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "Sorry could not update Student Details";
}
*/





public String deletebyname(String name){
try
{

String hql="delete from Class f where f.name = :name";
Session session= factory.openSession();
Query query=(Query) session.createSQLQuery(hql);
query.setParameter("name",name);
    int res=query.executeUpdate();
if(res>0)
return "Record is Successfully deleted!!!!";
}


catch (Exception e) {
e.printStackTrace();

}

return "Sorry could not delete !!!!!!";
}




public String deletebyid(int id){
try
{

String hql="delete from Class g where g.id = :id";
Session session= factory.openSession();
Query query=(Query) session.createSQLQuery(hql);
query.setParameter("id",id);
    int res=query.executeUpdate();
if(res>0)
return "Record is Successfully deleted!!!!";
}


catch (Exception e) {
e.printStackTrace();

}

return "Sorry could not delete !!!!!!";
}







}