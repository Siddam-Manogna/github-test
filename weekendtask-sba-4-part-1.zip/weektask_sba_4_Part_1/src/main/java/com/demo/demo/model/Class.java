package com.demo.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Class {

@Id
int id;
String name;
int age;
String Gender;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return Gender;
}
public void setGender(String gender) {
	Gender = gender;
}
@Override
public String toString() {
	return "Class [id=" + id + ", name=" + name + ", age=" + age + ", Gender=" + Gender + "]";
}
public Class(int id, String name, int age, String gender) {
	super();
	this.id = id;
	this.name = name;
	this.age = age;
	Gender = gender;
}
public Class() {
	
}




}